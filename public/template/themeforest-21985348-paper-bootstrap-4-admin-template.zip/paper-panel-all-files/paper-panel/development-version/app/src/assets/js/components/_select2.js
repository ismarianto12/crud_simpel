require('select2');
(function() {
    "use strict";
    $('.select2').select2();
}());