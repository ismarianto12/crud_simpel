require('.././libs/jquery.responsivetabs');
(function() {
    "use strict";
    $('.responsive-tab').responsiveTabs();
}());